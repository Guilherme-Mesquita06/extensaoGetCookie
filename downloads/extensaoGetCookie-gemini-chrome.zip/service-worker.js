importScripts('gemini.js', 'background.js');
