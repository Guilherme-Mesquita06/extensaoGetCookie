importScripts('gemini.js', 'vyral.js', 'background.js');
