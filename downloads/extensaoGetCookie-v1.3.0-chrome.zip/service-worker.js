importScripts('gemini.js', 'vyral.js', 'leonardo.js', 'background.js');
